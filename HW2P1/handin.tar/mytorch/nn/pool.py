import numpy as np
from resampling import *


class MaxPool2d_stride1():

    def __init__(self, kernel):
        self.kernel = kernel

    def forward(self, A):
        """
        Argument:
            A (np.array): (batch_size, in_channels, input_width, input_height)
        Return:
            Z (np.array): (batch_size, out_channels, output_width, output_height)
        """

        self.A = A
        self.batch_size, self.in_channels, self.input_width, self.input_height = A.shape
        self.out_width = self.input_width - self.kernel + 1
        self.out_height = self.input_height - self.kernel + 1

        Z = np.zeros((self.batch_size, self.in_channels, self.out_width, self.out_height))

        self.max_ind = np.zeros((self.batch_size, self.in_channels, self.out_width, self.out_height, 2), dtype=int)

        for n in range(self.batch_size):
            for c in range(self.in_channels):
                for i in range(self.out_width):
                    for j in range(self.out_height):
                        patch = A[n, c, i:i + self.kernel, j:j + self.kernel]
                        max_val = np.max(patch)
                        Z[n, c, i, j] = max_val
                        max_pos = np.unravel_index(np.argmax(patch, axis=None), patch.shape)
                        self.max_ind[n, c, i, j] = (i + max_pos[0], j + max_pos[1])

        return Z

    def backward(self, dLdZ):
        """
        Argument:
            dLdZ (np.array): (batch_size, out_channels, output_width, output_height)
        Return:
            dLdA (np.array): (batch_size, in_channels, input_width, input_height)
        """
        dLdA = np.zeros_like(self.A)

        for n in range(self.batch_size):
            for c in range(self.in_channels):
                for i in range(self.out_width):
                    for j in range(self.out_height):
                        (max_i, max_j) = self.max_ind[n, c, i, j]
                        dLdA[n, c, max_i, max_j] += dLdZ[n, c, i, j]

        return dLdA


class MeanPool2d_stride1():

    def __init__(self, kernel):
        self.kernel = kernel

    def forward(self, A):
        """
        Argument:
            A (np.array): (batch_size, in_channels, input_width, input_height)
        Return:
            Z (np.array): (batch_size, out_channels, output_width, output_height)
        """

        batch_size, in_channels, input_width, input_height = A.shape
        output_width = input_width - self.kernel + 1
        output_height = input_height - self.kernel + 1

        Z = np.zeros((batch_size, in_channels, output_width, output_height))

        for i in range(output_width):
            for j in range(output_height):
                patch = A[:, :, i:i + self.kernel, j:j + self.kernel]
                Z[:, :, i, j] = np.mean(patch, axis=(2, 3))

        return Z

    def backward(self, dLdZ):
        """
        Argument:
            dLdZ (np.array): (batch_size, out_channels, output_width, output_height)
        Return:
            dLdA (np.array): (batch_size, in_channels, input_width, input_height)
        """

        batch_size, out_channels, output_width, output_height = dLdZ.shape
        dLdA = np.zeros((batch_size, out_channels, output_width + self.kernel - 1, output_height + self.kernel - 1))

        for i in range(output_width):
            for j in range(output_height):
                dLdA[:, :, i:i + self.kernel, j:j + self.kernel] += dLdZ[:, :, i, j][:, :, None, None] / (
                            self.kernel * self.kernel)

        return dLdA


class MaxPool2d():

    def __init__(self, kernel, stride):
        self.kernel = kernel
        self.stride = stride

        # Create an instance of MaxPool2d_stride1
        self.maxpool2d_stride1 = MaxPool2d_stride1(kernel)
        self.downsample2d = Downsample2d(stride)

    def forward(self, A):
        """
        Argument:
            A (np.array): (batch_size, in_channels, input_width, input_height)
        Return:
            Z (np.array): (batch_size, out_channels, output_width, output_height)
        """

        A_maxpool2d = self.maxpool2d_stride1.forward(A)

        Z = self.downsample2d.forward(A_maxpool2d)

        return Z

    def backward(self, dLdZ):
        """
        Argument:
            dLdZ (np.array): (batch_size, out_channels, output_width, output_height)
        Return:
            dLdA (np.array): (batch_size, in_channels, input_width, input_height)
        """

        dLdZ_upsampled = self.downsample2d.backward(dLdZ)

        dLdA = self.maxpool2d_stride1.backward(dLdZ_upsampled)

        return dLdA


class MeanPool2d():

    def __init__(self, kernel, stride):
        self.kernel = kernel
        self.stride = stride

        # Create an instance of MaxPool2d_stride1
        self.meanpool2d_stride1 = MeanPool2d_stride1(kernel)
        self.downsample2d = Downsample2d(stride)

    def forward(self, A):
        """
        Argument:
            A (np.array): (batch_size, in_channels, input_width, input_height)
        Return:
            Z (np.array): (batch_size, out_channels, output_width, output_height)
        """

        A_meanpool2d = self.meanpool2d_stride1.forward(A)

        Z = self.downsample2d.forward(A_meanpool2d)

        return Z

    def backward(self, dLdZ):
        """
        Argument:
            dLdZ (np.array): (batch_size, out_channels, output_width, output_height)
        Return:
            dLdA (np.array): (batch_size, in_channels, input_width, input_height)
        """

        dLdZ_upsampled = self.downsample2d.backward(dLdZ)

        dLdA = self.meanpool2d_stride1.backward(dLdZ_upsampled)

        return dLdA
